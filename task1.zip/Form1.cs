using System;
using System.Windows.Forms;

namespace WinFormsRPG_NET8
{
    public partial class Form1 : Form
    {
        string nickname, cls, lore;
        int str = 0, agi = 0, intl = 0;

        public Form1()
        {
            InitializeComponent();
        }

        void GetPlayerData()
        {
            nickname = tbName.Text.Trim();
            cls = cbClass.Text.Trim();
            lore = tbLore.Text.Trim();
            if (string.IsNullOrWhiteSpace(nickname)) nickname = "Безымянный раб";
            if (string.IsNullOrWhiteSpace(lore)) lore = "Просто путник";
        }

        void PrintCard()
        {
            tbOutput.Text = $"=== КАРТОЧКА ПЕРСОНАЖА ===\r\n" +
                            $"Имя: {nickname}\r\n" +
                            $"Класс: {cls}\r\n" +
                            $"Предыстория: {lore}\r\n" +
                            $"Статы: Сила {str}, Ловкость {agi}, Интеллект {intl}";
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            GetPlayerData();
            PrintCard();
        }

        void UpdatePoints()
        {
            int s = (int)numStr.Value;
            int a = (int)numAgi.Value;
            int i = (int)numInt.Value;
            int rem = 20 - (s + a + i);
            lblRemain.Text = $"Осталось: {rem}";
            if (rem < 0) MessageBox.Show("Слишком много очков!");
        }

        private void numStr_ValueChanged(object sender, EventArgs e) => UpdatePoints();
        private void numAgi_ValueChanged(object sender, EventArgs e) => UpdatePoints();
        private void numInt_ValueChanged(object sender, EventArgs e) => UpdatePoints();

        private void btnConfirmStats_Click(object sender, EventArgs e)
        {
            str = (int)numStr.Value;
            agi = (int)numAgi.Value;
            intl = (int)numInt.Value;
            PrintCard();
        }

        private void btnDoor_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(tbDoorStr.Text, out int power))
            {
                MessageBox.Show("Введите число!");
                return;
            }
            string txt;
            if (power < 5) txt = "Ты ломаешь себе ключицу!";
            else if (power < 10) txt = "Дверь даже не шелохнулась.";
            else if (power < 15) txt = "Ты смог открыть дверь.";
            else if (power < 20) txt = "Дверь разлетается!";
            else txt = "ТЫДЫЩ!!! Ударная волна выбила дверь!";
            MessageBox.Show(txt);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
