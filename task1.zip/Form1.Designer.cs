namespace WinFormsRPG_NET8
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components=null;

        protected override void Dispose(bool disposing)
        {
            if(disposing && components!=null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblName = new System.Windows.Forms.Label();
            lblClass = new System.Windows.Forms.Label();
            lblLore = new System.Windows.Forms.Label();
            tbName = new System.Windows.Forms.TextBox();
            cbClass = new System.Windows.Forms.ComboBox();
            tbLore = new System.Windows.Forms.TextBox();
            btnCreate = new System.Windows.Forms.Button();
            tbOutput = new System.Windows.Forms.TextBox();
            lblStr = new System.Windows.Forms.Label();
            lblAgi = new System.Windows.Forms.Label();
            lblInt = new System.Windows.Forms.Label();
            numStr = new System.Windows.Forms.NumericUpDown();
            numAgi = new System.Windows.Forms.NumericUpDown();
            numInt = new System.Windows.Forms.NumericUpDown();
            lblRemain = new System.Windows.Forms.Label();
            btnConfirmStats = new System.Windows.Forms.Button();
            lblDoor = new System.Windows.Forms.Label();
            tbDoorStr = new System.Windows.Forms.TextBox();
            btnDoor = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)numStr).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numAgi).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numInt).BeginInit();
            SuspendLayout();
            // 
            // lblName
            // 
            lblName.Location = new System.Drawing.Point(12, 10);
            lblName.Name = "lblName";
            lblName.Size = new System.Drawing.Size(100, 23);
            lblName.TabIndex = 0;
            lblName.Text = "Никнейм:";
            // 
            // lblClass
            // 
            lblClass.Location = new System.Drawing.Point(12, 40);
            lblClass.Name = "lblClass";
            lblClass.Size = new System.Drawing.Size(100, 23);
            lblClass.TabIndex = 2;
            lblClass.Text = "Класс:";
            // 
            // lblLore
            // 
            lblLore.Location = new System.Drawing.Point(12, 70);
            lblLore.Name = "lblLore";
            lblLore.Size = new System.Drawing.Size(100, 23);
            lblLore.TabIndex = 4;
            lblLore.Text = "Предыстория:";
            // 
            // tbName
            // 
            tbName.Location = new System.Drawing.Point(120, 8);
            tbName.Name = "tbName";
            tbName.Size = new System.Drawing.Size(100, 23);
            tbName.TabIndex = 1;
            // 
            // cbClass
            // 
            cbClass.Items.AddRange(new object[] { "Воин", "Маг", "Вор", "Паладин" });
            cbClass.Location = new System.Drawing.Point(120, 38);
            cbClass.Name = "cbClass";
            cbClass.Size = new System.Drawing.Size(121, 23);
            cbClass.TabIndex = 3;
            // 
            // tbLore
            // 
            tbLore.Location = new System.Drawing.Point(121, 68);
            tbLore.Multiline = true;
            tbLore.Name = "tbLore";
            tbLore.Size = new System.Drawing.Size(154, 97);
            tbLore.TabIndex = 5;
            // 
            // btnCreate
            // 
            btnCreate.Location = new System.Drawing.Point(12, 160);
            btnCreate.Name = "btnCreate";
            btnCreate.Size = new System.Drawing.Size(75, 23);
            btnCreate.TabIndex = 6;
            btnCreate.Text = "Создать";
            btnCreate.Click += btnCreate_Click;
            // 
            // tbOutput
            // 
            tbOutput.Location = new System.Drawing.Point(12, 189);
            tbOutput.Multiline = true;
            tbOutput.Name = "tbOutput";
            tbOutput.Size = new System.Drawing.Size(254, 119);
            tbOutput.TabIndex = 7;
            // 
            // lblStr
            // 
            lblStr.Location = new System.Drawing.Point(324, 8);
            lblStr.Name = "lblStr";
            lblStr.Size = new System.Drawing.Size(51, 23);
            lblStr.TabIndex = 8;
            lblStr.Text = "Сила:";
            // 
            // lblAgi
            // 
            lblAgi.Location = new System.Drawing.Point(324, 38);
            lblAgi.Name = "lblAgi";
            lblAgi.Size = new System.Drawing.Size(65, 23);
            lblAgi.TabIndex = 10;
            lblAgi.Text = "Ловкость:";
            // 
            // lblInt
            // 
            lblInt.Location = new System.Drawing.Point(324, 68);
            lblInt.Name = "lblInt";
            lblInt.Size = new System.Drawing.Size(74, 23);
            lblInt.TabIndex = 12;
            lblInt.Text = "Интеллект:";
            // 
            // numStr
            // 
            numStr.Location = new System.Drawing.Point(435, 8);
            numStr.Name = "numStr";
            numStr.Size = new System.Drawing.Size(120, 23);
            numStr.TabIndex = 9;
            numStr.ValueChanged += numStr_ValueChanged;
            // 
            // numAgi
            // 
            numAgi.Location = new System.Drawing.Point(435, 40);
            numAgi.Name = "numAgi";
            numAgi.Size = new System.Drawing.Size(120, 23);
            numAgi.TabIndex = 11;
            numAgi.ValueChanged += numAgi_ValueChanged;
            // 
            // numInt
            // 
            numInt.Location = new System.Drawing.Point(435, 70);
            numInt.Name = "numInt";
            numInt.Size = new System.Drawing.Size(120, 23);
            numInt.TabIndex = 13;
            numInt.ValueChanged += numInt_ValueChanged;
            // 
            // lblRemain
            // 
            lblRemain.Location = new System.Drawing.Point(300, 100);
            lblRemain.Name = "lblRemain";
            lblRemain.Size = new System.Drawing.Size(100, 23);
            lblRemain.TabIndex = 14;
            lblRemain.Text = "Осталось: 20";
            // 
            // btnConfirmStats
            // 
            btnConfirmStats.Location = new System.Drawing.Point(300, 126);
            btnConfirmStats.Name = "btnConfirmStats";
            btnConfirmStats.Size = new System.Drawing.Size(117, 35);
            btnConfirmStats.TabIndex = 15;
            btnConfirmStats.Text = "Подтвердить";
            btnConfirmStats.Click += btnConfirmStats_Click;
            // 
            // lblDoor
            // 
            lblDoor.Location = new System.Drawing.Point(300, 180);
            lblDoor.Name = "lblDoor";
            lblDoor.Size = new System.Drawing.Size(100, 23);
            lblDoor.TabIndex = 16;
            lblDoor.Text = "Сила для двери:";
            // 
            // tbDoorStr
            // 
            tbDoorStr.Location = new System.Drawing.Point(410, 178);
            tbDoorStr.Name = "tbDoorStr";
            tbDoorStr.Size = new System.Drawing.Size(100, 23);
            tbDoorStr.TabIndex = 17;
            // 
            // btnDoor
            // 
            btnDoor.Location = new System.Drawing.Point(300, 210);
            btnDoor.Name = "btnDoor";
            btnDoor.Size = new System.Drawing.Size(100, 53);
            btnDoor.TabIndex = 18;
            btnDoor.Text = "Открыть дверь";
            btnDoor.Click += btnDoor_Click;
            // 
            // Form1
            // 
            ClientSize = new System.Drawing.Size(600, 320);
            Controls.Add(lblName);
            Controls.Add(tbName);
            Controls.Add(lblClass);
            Controls.Add(cbClass);
            Controls.Add(lblLore);
            Controls.Add(tbLore);
            Controls.Add(btnCreate);
            Controls.Add(tbOutput);
            Controls.Add(lblStr);
            Controls.Add(numStr);
            Controls.Add(lblAgi);
            Controls.Add(numAgi);
            Controls.Add(lblInt);
            Controls.Add(numInt);
            Controls.Add(lblRemain);
            Controls.Add(btnConfirmStats);
            Controls.Add(lblDoor);
            Controls.Add(tbDoorStr);
            Controls.Add(btnDoor);
            Name = "Form1";
            Text = "taskguild";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)numStr).EndInit();
            ((System.ComponentModel.ISupportInitialize)numAgi).EndInit();
            ((System.ComponentModel.ISupportInitialize)numInt).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Label lblName,lblClass,lblLore;
        private System.Windows.Forms.TextBox tbName,tbLore;
        private System.Windows.Forms.ComboBox cbClass;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.TextBox tbOutput;

        private System.Windows.Forms.Label lblStr,lblAgi,lblInt;
        private System.Windows.Forms.NumericUpDown numStr,numAgi,numInt;
        private System.Windows.Forms.Label lblRemain;
        private System.Windows.Forms.Button btnConfirmStats;

        private System.Windows.Forms.Label lblDoor;
        private System.Windows.Forms.TextBox tbDoorStr;
        private System.Windows.Forms.Button btnDoor;
    }
}
